<?php
    $conn = mysqli_connect('localhost','root','','library_ms') or die('connection failed');     
?>